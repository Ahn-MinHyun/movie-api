import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='goldumin',
    application_name='movie-recommendation-api',
    app_uid='MKt6PH3p4MGrxQKnjj',
    org_uid='fef97d71-3029-42cb-a4f3-c6d032f578ca',
    deployment_uid='e0ef3be7-9184-425f-bc02-39223730a474',
    service_name='movie-recommendation-api',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='4.5.3',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'movie-recommendation-api-dev-api', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
